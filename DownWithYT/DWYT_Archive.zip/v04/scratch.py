###            ###
#    SCRATCH     #
###            ###


'''
self.title
self.url
self.thumbnail
self.video_id
self.length
self.author
self.channel_url
self.channel_id
self.views
self.desc

title,url,thumbnail,video_id,length,author,channel_url,channel_id,views,desc


search YouTube
create 
create, edit, save, and load custom lists
playlist handling
download videos or audio

