from setuptools import setup, find_packages, os
setup(name = 'v03', packages = find_packages())
